using UTC.BAL.Interface;
using UTC.Core.App.Helper;
using UTC.Core.App.Pages.Base;
using UTC.DAL.Entities;
using UTC.Model.Base;
using UTC.Model.Users;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UTC.Model.EVC_Portal;

namespace UTC.Core.App.Pages.EVC_Portal
{
    public class EVC_DashboardModel : BasePageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IUserManager _userManager;
        private readonly IEVCManager _eVCManager;
       // public LoginViewModel _loginSession;
        private readonly UTC.DAL.Entities.Digi2l_DevContext _context;
        public EVC_DashboardModel(ILogger<IndexModel> logger, IUserManager userManager, UTC.DAL.Entities.Digi2l_DevContext context, IOptions<ApplicationSettings> config, IEVCManager eVCManager)
        : base(config)

        {
            _logger = logger;
            _userManager = userManager;
            _context = context;
            _eVCManager = eVCManager;
        }


        [BindProperty(SupportsGet = true)]
        public UserViewModel UserViewModel { get; set; }

        [BindProperty(SupportsGet = true)]
        public IList<TblUserRole> TblUserRole { get; set; }
        [BindProperty(SupportsGet = true)]
        public List<UserViewModel> UserVMList { get; set; }
        [BindProperty(SupportsGet = true)]
        public UserViewModel UserVM { get; set; }
        [BindProperty(SupportsGet = true)]
        public EVC_DashboardViewModel eVC_DashBoardViewModel { get; set; }
        [BindProperty(SupportsGet = true)]
        public EVC_RegistrationPortalViewModel RegisterationPortalViewModel { get; set; }
        [BindProperty(SupportsGet = true)]
        public List<lattestAllocationViewModel> LattestAllocationViewModel { get; set; }


        public IActionResult OnGet()
        {

            if (_loginSession == null)
            {
                return RedirectToPage("Index");
            }
            else
            {
                int userId = _loginSession.UserViewModel.UserId;
                //getdashboard data
                if (userId != null)
                {
                    eVC_DashBoardViewModel = _eVCManager.EvcByUserId(userId);
                    LattestAllocationViewModel = _eVCManager.GetListOFLattestAllocation(userId);
                }

                //get user list

                if (_loginSession.RoleViewModel.CompanyId > 0)
                {
                    TblUserRole = _context.TblUserRoles
                  .Include(t => t.Role)
                  .Include(t => t.User)
                  .Include(t => t.Company)
                  .Include(t => t.ModifiedByNavigation).Where(x => x.IsActive == true && x.CompanyId == _loginSession.RoleViewModel.CompanyId).OrderByDescending(x => x.UserId).ToList();
                }

                if (TblUserRole != null && TblUserRole.Count > 0)
                {
                    UserVMList = new List<UserViewModel>();

                    foreach (var item in TblUserRole)
                    {
                        UserVM = new UserViewModel();
                        UserVM.UserId = (int)item.UserId;
                        UserVM.FirstName = item.User.FirstName;
                        UserVM.LastName = item.User.LastName;
                        UserVM.RoleName = item.Role.RoleName;
                        // UserVM. = item.CompanyId

                        UserVMList.Add(UserVM);
                    }
                }
                if (UserVMList != null && UserVMList.Count > 0)
                {
                    ViewData["AssignToList"] = new SelectList(UserVMList, "UserId", "FullNameAndRole");
                }

                //get lead list

                return Page();
            }

        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(UserViewModel.Email) && !string.IsNullOrEmpty(UserViewModel.Password))
            {
                LoginViewModel loginVM = _userManager.GetUserByLogin(UserViewModel.Email, UserViewModel.Password);
                if (loginVM != null && loginVM.UserViewModel != null && loginVM.UserViewModel.UserId != 0)
                {
                    SessionHelper.SetObjectAsJson(HttpContext.Session, "LoginUser", loginVM);
                    return new RedirectToPageResult("/Dashboard");
                }
                else
                {
                    TempData["Auth"] = false;
                    return new RedirectToPageResult("Index");
                }
            }
            else
            {
                TempData["Auth"] = false;
                return new RedirectToPageResult("Index");
            }
        }
    }
}
