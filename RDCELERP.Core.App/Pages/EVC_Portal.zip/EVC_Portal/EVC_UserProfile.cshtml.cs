using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using UTC.DAL.Entities;
using UTC.Core.App.Pages.Base;
using Microsoft.Extensions.Options;
using UTC.Model.Base;
using UTC.Common.Helper;

namespace UTC.Core.App.Pages.EVC_Portal
{
    public class EVC_UserProfileModel : BasePageModel
    {
        private readonly UTC.DAL.Entities.Digi2l_DevContext _context;
        public readonly IOptions<ApplicationSettings> _config;
        private CustomDataProtection _protector;


        public EVC_UserProfileModel(UTC.DAL.Entities.Digi2l_DevContext context, IOptions<ApplicationSettings> config, CustomDataProtection protector)
        : base(config)
        {
            _context = context;
            _config = config;
            _protector = protector;
        }

        public TblUser TblUser { get; set; }
        public IList<TblUserRole> TblUserRole { get; set; }

        public IActionResult OnGetAsync(string id)
        {

            if (_loginSession == null)
            {
                return RedirectToPage("/index");
            }
            else
            {
                int userId = _loginSession.UserViewModel.UserId;

                //if (id == null)
                //{
                //    return NotFound();
                //}

                TblUser = _context.TblUsers
                    .Include(t => t.CreatedByNavigation)
                    .Include(t => t.ModifiedByNavigation).FirstOrDefault(m => m.IsActive == true && m.UserId == Convert.ToInt32(userId));
                if (TblUser != null)
                {

                    TblUser.Email = SecurityHelper.DecryptString(TblUser.Email, _config.Value.SecurityKey);
                    TblUser.Phone = SecurityHelper.DecryptString(TblUser.Phone, _config.Value.SecurityKey);
                    TblUser.Password = SecurityHelper.DecryptString(TblUser.Password, _config.Value.SecurityKey);

                }

                if (TblUser == null)
                {
                    return NotFound();
                }
                else
                {

                    TblUserRole = _context.TblUserRoles
                        .Where(m => m.UserId == (Convert.ToInt32(id)))
                         .Include(t => t.Role)
                         .Include(t => t.Company).Where(x => x.IsActive == true).ToList();


                    //if (TblUserRole != null)
                    //{
                    //    foreach(var items in TblUserRole)
                    //    {
                    //        items.User.Email = SecurityHelper.DecryptString(items.User.Email, _config.Value.SecurityKey);
                    //        items.User.Phone = SecurityHelper.DecryptString(items.User.Phone, _config.Value.SecurityKey);
                    //    }

                    //}
                    //.Include(t => t.Company).ToList();

                }

                return Page();
            }
        }
    }
}
